using System.Linq;
using UnityEngine;

/// <summary>
/// 봇 (읽히는 행동 = 추리 단서):
///  1순위: 내 꼴등픽이 꼴찌가 아니면 → 감속으로 처박기 (티키토플 근본 플레이)
///  2순위: 내 1등픽이 선두가 아니면 → 부스트로 밀어주기
/// </summary>
public class BotController : MonoBehaviour
{
    [SerializeField] private ItemExecutor executor;
    [SerializeField] private RaceManager raceManager;
    [Range(0f, 1f)] public float actChancePerSecond = 0.5f;

    private PlayerState bot;

    /// <summary>바인딩된 플레이어 ID (-1 = 미바인딩). 로스터 관리용.</summary>
    public int BoundId => bot != null ? bot.PlayerId : -1;

    public void Bind(PlayerState state) => bot = state;

    private void Update()
    {
        if (bot == null || GameManager.Instance.CurrentPhase != GamePhase.Racing) return;
        if (!bot.IsCooldownReady || bot.Items.Count == 0) return;
        if (Random.value > actChancePerSecond * Time.deltaTime) return;

        var running = raceManager.Racers.Where(r => !r.HasFinished)
                                        .OrderByDescending(r => r.Progress).ToList();
        if (running.Count < 2) return;

        var myFirst = raceManager.GetRacer(bot.Bet.firstId);
        var slow  = bot.Items.FirstOrDefault(i => i.kind == ItemKind.Slow);
        var boost = bot.Items.FirstOrDefault(i => i.kind == ItemKind.Boost);

        // 1순위: 1등픽이 선두가 아니면 밀어주기
        if (boost != null && myFirst != null && !myFirst.HasFinished &&
            running[0].RacerId != bot.Bet.firstId)
        {
            executor.TryUseItem(bot, boost, bot.Bet.firstId);
            return;
        }

        // 2순위: 내 픽이 아닌 침입자가 선두면 감속 견제
        int leaderId = running[0].RacerId;
        bool leaderIsMyPick = leaderId == bot.Bet.firstId
                           || leaderId == bot.Bet.secondId
                           || leaderId == bot.Bet.thirdId;
        if (slow != null && !leaderIsMyPick)
            executor.TryUseItem(bot, slow, leaderId);
    }
}
